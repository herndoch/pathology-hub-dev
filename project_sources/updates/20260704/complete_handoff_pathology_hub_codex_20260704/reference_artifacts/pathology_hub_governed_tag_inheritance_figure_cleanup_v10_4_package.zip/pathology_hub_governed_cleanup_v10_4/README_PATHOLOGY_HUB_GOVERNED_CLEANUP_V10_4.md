# Pathology Hub governed cleanup v10.4

This package contains one Colab notebook for the Evidence/Lesson/Research tag governance cleanup requested on 2026-07-04.

## What it does

- Loads ABPath source-truth tags from the included/uploaded `pathology_hub_abpath_source_tags.zip`.
- Loads WHO processed tags from `gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json` and accepts fuzzy matches to ABPath by default.
- Preserves PathOut tags as high-quality local tags unless they trip obvious junk rules.
- Removes generated lecture/textbook artifact tags from promoted `primary_tag` fields by mapping to approved tags or inheriting the most recent meaningful tag in the same lecture/book sequence.
- Excludes rows with no confident mapping and no prior sequence tag from the approved tag index by setting governed `__UNMAPPED__`.
- Filters junk textbook figure derivatives from the served figure map using dimensions/aspect-ratio/header-footer rules.
- Uploads staged outputs and promotes them over backend-consumed paths with backups.
- Restarts Cloud Run and runs health/API proof using the `X-API-Key` Colab secret when present.

## Promotion default

`PROMOTION_MODE = "backup_replace_live"` by default, per the user request.

The notebook still refuses promotion if the clear audit fails.

## What it does not delete

It does not delete raw PDFs or videos. It backs up live metadata before overwriting it. For images, it replaces the served figure map with a filtered map and writes an exclusion manifest.

## Sequence consistency

Lecture vector docstore rows are treated as the canonical sequence for lecture tag inheritance; routed chunks and lecture tag maps reuse those decisions by chunk/record keys where possible. Textbook chunks are treated as canonical for chunk-level metadata; textbook vector docstore rows reuse chunk decisions when keys match.
