# Governed tag policy v10.4

## Approved authorities
1. ABPath gold tags from user-provided source list.
2. WHO processed JSON tags, mapped to ABPath by accepted fuzzy matching when possible.
3. PathOut tags as high-quality local diagnostic tags unless they are obvious artifacts.
4. Explicitly approved local tags in future governance runs.

## Rejected / suppressed tag classes
- Tags containing `::Lectures::` or `::Textbooks::`.
- Page/slide/file/time/digital-slide-derived tags.
- Very weak leaves such as generic `Figure`, `Overview`, `Features`, or `Clear_Cell_Change` unless already source-approved.

## Inheritance
For lecture and textbook sequences, weak/unapproved tags inherit the most recent meaningful governed tag within the same sequence. This keeps short fragments and figures attached to nearby context without inventing tags.

## Figures
Derived figure records with tiny dimensions, extreme strip aspect ratios, or header/footer evidence are excluded from the served figure map. Raw source files remain untouched.
