# WHO tag and source locator reality

Legacy WHO tag-bearing source location we know about:

```text
gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json
```

Earlier normalized target paths that may or may not exist in the bucket:

```text
gs://pathology_hub/02_normalized/who/who_entities.jsonl
gs://pathology_hub/02_normalized/who/who_chunks.jsonl
gs://pathology_hub/02_normalized/who/who_figures.jsonl
gs://pathology_hub/03_indexes/who/who_fts.sqlite
```

Raw source locations:

```text
gs://pathology-hub-0/source_pdfs/
gs://pathology-hub-0/source_videos/
```

v09.3 builds a registry from those raw source roots and joins normalized records to raw source files when explicit fields or conservative source_id/stem matching allow it.
