# Pathology Hub ELR Tag Runtime v09.3 — source locator + WHO fix

This package fixes two gaps in v09/v09.2:

1. It explicitly discovers raw source files under `gs://pathology-hub-0/source_pdfs/` and `gs://pathology-hub-0/source_videos/` and builds a `raw_source_file_registry` plus record-level source locator fields.
2. It treats WHO as a required tagged source and searches both legacy WHO JSON and normalized WHO paths, including `gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json` and `gs://pathology_hub/02_normalized/who/**`.

Run the single notebook. It will fail if WHO tag-bearing rows are not loaded unless `REQUIRE_WHO_TAGS=False` is explicitly set.
