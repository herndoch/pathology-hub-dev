# v10.5.2 API proof fix

Use this when v10.5 promotion/health succeeded but POST API proof returned 401 because the notebook used the wrong Colab secret.

This notebook prefers `HUB_API`, then `PATHOLOGY_HUB_API_KEY`, then `X-API-Key`, then GCP Secret Manager `pathology-hub-api-key`. It sends the selected value as the HTTP header `X-API-Key`. It does not promote or modify live artifacts.
