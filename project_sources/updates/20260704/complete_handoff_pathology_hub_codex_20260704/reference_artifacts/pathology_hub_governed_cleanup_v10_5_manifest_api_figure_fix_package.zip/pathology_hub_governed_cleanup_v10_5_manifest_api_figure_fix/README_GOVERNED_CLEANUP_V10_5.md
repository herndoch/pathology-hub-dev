# Pathology Hub Governed Cleanup v10.5

Run after v10.4.

Purpose:
- verify live governed `primary_tag` fields from current GCS metadata;
- patch stale manifest summaries so health output no longer shows old lecture/textbook junk tag counts;
- perform stricter served-figure filtering using dimension/aspect-ratio rules and actual image dimensions when available;
- run authenticated API proof using Colab secret `X-API-Key`;
- promote by default with backups.

Default promotion config:

```python
PROMOTION_MODE = "backup_replace_live"
RESTART_CLOUD_RUN_AFTER_PROMOTION = True
RUN_API_PROOF = True
```

It does not delete raw PDFs, raw videos, or embeddings. It replaces only live manifest summaries and the served textbook public figure map after backup.
