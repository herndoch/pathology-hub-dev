# Curriculum Tag Policy v11

## Canonical hierarchy
- ABPath tags are the gold tag source.
- WHO processed tags are official-source tags, but runtime canonicalization maps them to ABPath when fuzzy match score is >= 90.
- PathOut tags are auto-approved local practical diagnostic tags unless they hit junk/artifact rules.
- Lecture/textbook-generated ontology tags are not accepted as permanent tags unless they map to ABPath/WHO/PathOut-approved tags.

## Inheritance rule
Lecture and textbook records are ordered educational sequences. Weak-context records should inherit the most recent meaningful tag within a bounded distance rather than inventing a new tag.

Defaults:
- Lecture max distance: 600 seconds or 12 rows within the same lecture/video.
- Textbook max distance: 2 pages or 25 rows within the same source/book.

If no meaningful prior tag exists within the allowed sequence distance, the record becomes governed `__UNMAPPED__` and is excluded from approved tag browsing.

## Explicitly disallowed as visible tags
Tags containing these patterns are excluded from governed tag browsing:

```text
::Lectures::
::Textbooks::
Page_<number>
Slide_<number>
Digital_Pathology_Slide
Pathology_Slide
Case_<number>
Error
file-like names such as .svs, .ndpi, .jpg, .png
```

## Figures
Only derived figure-map records are filtered. Raw PDFs remain preserved. Thin strips, tiny crops, and extreme aspect-ratio images are excluded from the served figure map after backup.
