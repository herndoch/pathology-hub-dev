# Pathology Hub Curriculum Tag Hardening v11

Generated: 2026-07-04

## Workstream
Evidence/Lesson/Research RAG — curriculum mapping tag governance.

## Purpose
Remove generated lecture/textbook ontology junk from retrieval-facing tags and build an approved-only curriculum tag layer.

This notebook implements the decisions:

1. PathOut-only tags are auto-approved as local curriculum tags.
2. WHO tags from `gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json` are fuzzy matched to ABPath gold tags and auto-accepted at score >= 90.
3. Lecture/textbook weak-context chunks inherit the most recent meaningful tag within max distance.
4. Chunks with no approved mapping and no prior same-sequence context remain governed `__UNMAPPED__` and are excluded from approved tag browsing.
5. Secondary facets are intentionally held off.
6. PathOut-local tags remain local approved tags even if not in ABPath.

## Default behavior
Promotion is enabled by default:

```python
PROMOTION_MODE = "backup_replace_live"
RESTART_CLOUD_RUN_AFTER_PROMOTION = True
RUN_API_PROOF = True
```

The notebook still aborts promotion if the clear audit fails.

## Inputs
- ABPath source tag ZIP, usually `pathology_hub_abpath_source_tags.zip`.
- WHO processed JSON at `gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json`.
- Current live textbook/pathout/lecture metadata paths in GCS.
- Colab secret `X-API-Key` for authenticated API proof.

## Outputs
- Governed textbook/pathout/lecture metadata JSONL.
- Governed vector manifests.
- Approved-only curriculum tag SQLite index.
- Approved tag catalog/tree/browser.
- WHO fuzzy-match audit.
- Lecture/textbook inheritance audit examples.
- Derived textbook figure exclusion audit.
- GCS backup/promotion audit.
- API proof JSON.

## Important caveat
The notebook does not delete raw PDFs or videos and does not rebuild embeddings. It patches retrieval-facing metadata and derived figure-map records only after backing up live targets.
