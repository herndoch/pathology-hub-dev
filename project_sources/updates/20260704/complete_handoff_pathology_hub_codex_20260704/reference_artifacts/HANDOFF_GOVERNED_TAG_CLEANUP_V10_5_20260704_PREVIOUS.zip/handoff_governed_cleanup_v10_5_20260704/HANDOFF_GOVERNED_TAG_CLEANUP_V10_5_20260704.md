# Handoff — Governed Tag Cleanup v10.5 and Curriculum Mapping Preparation

Generated: 2026-07-04T16:38:27+00:00

## Workstream name

Evidence/Lesson/Research RAG — governed tag cleanup, curriculum tag governance, and source metadata hygiene.

This remains separate from:

- report-style RAG / pathology report drafting
- gross template generation
- standalone HTML rendering
- backend API implementation work except where metadata promotion touches live loaders
- Custom GPT frontend configuration except for downstream instruction/status updates

## Purpose

The purpose of this work was to stop generated lecture/textbook junk tags from polluting curriculum mapping and retrieval surfaces while preserving useful diagnostic tags from ABPath, WHO, and PathOut.

The user clarified the desired policy:

1. PathOut tags are often clinically useful and should be auto-approved as local curriculum tags unless obvious junk/root-error rules fail.
2. WHO processed tags should be fuzzy-matched to ABPath and auto-accepted at score >= 90.
3. Lecture/textbook tags that contain source artifacts such as `::Lectures::`, `::Textbooks::`, `Slide_`, `Page_N`, digital slide filenames, or raw lecture/book names should not become ontology nodes.
4. For weak-context lecture/textbook chunks, use sequence inheritance rather than generating new tags.
5. If no meaningful prior context exists, keep the record untagged/excluded from tag browsing rather than inventing a tag.
6. Hold off on secondary content facets for now.

## Inputs assumed

- Canonical project: `pathology-annotation-project`.
- Canonical artifact bucket: `gs://pathology_hub`.
- Legacy/source bucket: `gs://pathology-hub-0`.
- Active Cloud Run service: `pathology-hub-v04`.
- Existing one Action endpoint: `POST /evidence/search` / `searchEvidence`.
- Live source families before governance: WHO, textbooks, journals, PathOut, lectures/videos.
- ABPath gold tag ZIP supplied by user: `pathology_hub_abpath_source_tags.zip`.
- WHO tag-bearing source files: `gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json`.
- Existing Textbook v2.1, PathOut v2.3, and Lecture v10.3 metadata promoted previously.

## Outputs produced by the governed cleanup phase

### v10.4 governed tag cleanup

v10.4 produced the governed approved tag index and removed forbidden generated lecture/textbook tags from the governed tag index.

From reviewed v10.4 summary:

```json
{
  "promotion_performed": true,
  "clear_audit_passed": true,
  "forbidden_primary_tag_total_after_governance": 0,
  "tag_index_records": 323274,
  "tag_index_unique_tags": 6035,
  "unmapped_records_in_tag_index": 0,
  "who_original_unique_tags": 2150,
  "who_approved_mapped_unique": 2103,
  "pathout_approved_local_unique": 4048
}
```

Source record breakdown in the governed index:

```json
[
  {
    "source": "lectures",
    "n": 126207,
    "unique_tags": 1647
  },
  {
    "source": "pathout",
    "n": 8794,
    "unique_tags": 4048
  },
  {
    "source": "textbooks",
    "n": 188273,
    "unique_tags": 2622
  }
]
```

Authority breakdown:

```json
[
  {
    "tag_authority": "abpath_gold",
    "n": 3333
  },
  {
    "tag_authority": "pathout_approved_local",
    "n": 2545
  },
  {
    "tag_authority": "who_processed_or_who_to_abpath",
    "n": 157
  }
]
```

### v10.5 manifest/API/figure cleanup pass

v10.5 was then run to clean stale manifest summaries, rerun API proof, and perform stricter served-figure-map filtering.

From v10.5 summary:

```json
{
  "promotion_mode": "backup_replace_live",
  "promotion_performed": true,
  "figure_filter_counts": {
    "total": 49526,
    "kept": 49525,
    "excluded": 1
  },
  "metadata_scan_counts": {
    "textbooks": {
      "counts": {
        "total": 79320,
        "primary_tag_mapped": 79320,
        "primary_tag_governed_mapped": 79320
      },
      "unique_primary_tags": 2597
    },
    "pathout": {
      "counts": {
        "total": 4397,
        "primary_tag_mapped": 4397,
        "primary_tag_governed_mapped": 4397
      },
      "unique_primary_tags": 4048
    },
    "lectures": {
      "counts": {
        "total": 42069,
        "primary_tag_mapped": 42069,
        "primary_tag_governed_mapped": 42069
      },
      "unique_primary_tags": 1647
    }
  }
}
```

The initial v10.5 API proof used a stale/wrong Colab secret and returned `401 Unauthorized` for POST tests, even though health returned 200. That auth problem was then resolved by using the working Colab secret `HUB_API`, sent under HTTP header `X-API-Key`.

### v10.5.2 authenticated API proof

Authenticated API proof output pasted by the user showed:

```text
API key loaded: True length: 47
API key fingerprint: f1e4ad2e
HEALTH 200
['lectures'] status 200 forbidden 0
['who', 'textbooks', 'pathout', 'journals'] status 200 forbidden 0
['textbooks', 'pathout'] status 200 forbidden 0
API PROOF PASSED: all searches returned 200 and no forbidden primary tags.
```

The proof JSON was uploaded by the notebook to:

```text
gs://pathology_hub/06_audits/tags/governance/v10_5/PATHOLOGY_HUB_GOVERNED_CLEANUP_API_PROOF_v10_5_2.json
```

## Final status claim allowed after this handoff

Use this wording:

> Governed tag cleanup v10.5 is live and authenticated API-proven for the existing `searchEvidence` endpoint. Textbook, PathOut, and lecture/video metadata exposed through standard retrieval no longer returns tested forbidden generated lecture/textbook artifact tag patterns. WHO processed tags have been loaded/mapped in the governance layer; PathOut tags are treated as approved local curriculum tags; lecture/textbook-generated artifact tags are excluded from governed tag browsing and retrieval-facing metadata.

## Claims not allowed yet

Do not claim:

1. Explicit tag-browse request fields are live unless a tag-aware backend/OpenAPI patch is separately deployed and health-checked.
2. v11 curriculum hardening is live; v11 notebook/package has been generated but not run/promoted/proven in this handoff.
3. Raw all-site PathOut outside the AP-diagnostic/local governed scopes is fully tagged.
4. Raw PDFs/videos were deleted or altered.
5. Junk figure removal is exhaustive. v10.5 filtered served figure records according to implemented rules, but the run summary showed only one served figure-map exclusion in that pass.

## Schemas / fields used

New governed metadata fields may be present in patched records:

```text
primary_tag_original_pre_governance_v10_4
primary_tag_governed
tag_governance_status
tag_governance_basis
tag_authority
```

Governance categories used conceptually:

```text
abpath_gold
who_processed_or_who_to_abpath
pathout_approved_local
inherited_context
rejected_generated
excluded_junk
unmapped_no_context
```

## GCS paths produced or referenced

Governance/audit paths:

```text
gs://pathology_hub/02_normalized/tags/governance/v10_4/
gs://pathology_hub/06_audits/tags/governance/v10_4/
gs://pathology_hub/02_normalized/tags/governance/v10_5/
gs://pathology_hub/06_audits/tags/governance/v10_5/
gs://pathology_hub/06_audits/tags/governance/v10_5/PATHOLOGY_HUB_GOVERNED_CLEANUP_API_PROOF_v10_5_2.json
```

WHO source tags:

```text
gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json
```

Backups were written under a governance backup prefix, for example:

```text
gs://pathology_hub/99_backups/governance_v10_4/<timestamp>/
gs://pathology_hub/99_backups/governance_v10_5/<timestamp>/
```

## API endpoints needed/provided

Provided endpoint remains unchanged:

```text
POST /evidence/search
operationId: searchEvidence
```

Active service remains:

```text
https://pathology-hub-v04-vorn5q2kga-uc.a.run.app
```

Authentication header remains:

```text
X-API-Key
```

Important auth note: in Colab, the working secret name was `HUB_API`. The HTTP header remains `X-API-Key`. GPT Builder should use the same working value from `HUB_API` / GCP Secret Manager under the header name `X-API-Key`.

## Integration points

- Custom GPT frontend should keep using one Action only: `searchEvidence`.
- GPT instructions should say `primary_tag` is governed routing/curriculum metadata, not diagnostic truth.
- GPT should not expose or reproduce tag paths containing `::Lectures::`, `::Textbooks::`, `Slide_`, `Digital_Pathology_Slide`, `Pathology_Slide`, `Benign_Cystic_Neck_Mass_Case_01`, or `::Error` as curriculum tags.
- GPT can trust PathOut tags as approved local curriculum tags after governance unless a future audit rejects specific branches.
- GPT can treat WHO-to-ABPath mappings as accepted when they passed the governance threshold.
- Explicit browse-by-tag UI/API remains a separate backend capability unless the tag-aware runtime is deployed and proven.

## Tests/audits

Passed:

- v10.4 clear audit passed.
- v10.4 forbidden primary-tag total after governance: 0.
- v10.4 governed tag index contains 0 `__UNMAPPED__` records.
- v10.4 governed tag index contains 0 records/tags for tested forbidden patterns.
- v10.5 promotion performed with `backup_replace_live`.
- v10.5 metadata scan shows textbook/pathout/lecture backend-consumed records all mapped in `primary_tag` and `primary_tag_governed`.
- v10.5.2 authenticated API proof passed: three POST tests returned 200 and 0 forbidden primary tags.

Incomplete or requiring caution:

- v10.5 original proof file shows 401 because it used a bad/cached Colab secret. It is superseded by v10.5.2 proof.
- Figure cleanup is not proven exhaustive; v10.5 excluded only one served public figure-map record in that run.
- v11 curriculum hardening is planned/generated but not promoted/proven.

## Known limitations

- Existing API version remains `evidence_search_response.v1.5.8`; tag-aware query modes are not part of the proven current OpenAPI unless separately deployed.
- Governance changes do not alter embeddings or raw source text. Vector search can still retrieve raw snippets that contain words like “slide” or page text, but these should not appear as approved tag paths.
- Some inherited tags may be imperfect; inheritance prevents junk ontology creation but can propagate context too far if ordering metadata is poor. v11 is intended to harden max-distance inheritance.
- Figure cleanup needs further visual/dimension auditing if header/footer strips still appear in returned figures.

## Next steps

1. Update master project spine/workstream status with the v10.5 governed cleanup status.
2. Update GPT instructions to enforce governed tag policy and avoid showing junk tag paths.
3. Keep current `searchEvidence` OpenAPI unless/until explicit tag-aware backend runtime is deployed.
4. Run v11 curriculum hardening if desired, using user decisions:
   - auto-approve PathOut local tags
   - auto-accept WHO fuzzy matches to ABPath at score >= 90
   - max lecture inheritance: 10 minutes / 12 rows
   - max textbook inheritance: 2 pages / 25 rows
   - no secondary facets for now
5. Build a dedicated figure de-junking pass if junk header/footer images remain visible.

