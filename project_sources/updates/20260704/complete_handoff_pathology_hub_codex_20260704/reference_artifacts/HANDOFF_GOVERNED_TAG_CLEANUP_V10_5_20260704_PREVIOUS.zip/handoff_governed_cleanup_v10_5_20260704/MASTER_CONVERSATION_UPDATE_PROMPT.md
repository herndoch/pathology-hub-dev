# Master conversation update prompt

Please ingest this handoff packet into Conversation A — Master Project Spine.

Use `HANDOFF_GOVERNED_TAG_CLEANUP_V10_5_20260704.md` as the primary handoff source and reconcile it with the current master files.

Required updates:

1. Update `CURRENT_MASTER_SPINE` to record that governed tag cleanup v10.5 is live and API-proven for standard `searchEvidence` retrieval.
2. Update `WORKSTREAM_STATUS` under Evidence/Lesson/Research RAG:
   - Textbook, PathOut, and Lecture metadata are governed and standard API proof returned no forbidden generated lecture/textbook artifact tags.
   - WHO processed tags were loaded/mapped in the governance layer.
   - PathOut tags are approved local curriculum tags.
   - Explicit tag-browse API remains pending unless separately deployed/proven.
3. Update `DECISIONS_LOG` with the governance decisions:
   - PathOut-only tags auto-approved as local curriculum tags.
   - WHO-to-ABPath fuzzy matches accepted at score >= 90.
   - Lecture/textbook generated source-artifact tags disallowed from visible curriculum tag surfaces.
   - Weak-context lecture/textbook records should inherit prior meaningful tag or remain untagged/excluded from tag browsing.
   - Secondary curriculum facets deferred.
4. Update `SCHEMA_REGISTRY` with governed metadata fields, but do not mark tag-aware request schema live unless a backend deployment proves it.
5. Update API/auth notes:
   - HTTP auth header remains `X-API-Key`.
   - Working key value matched Colab `HUB_API` and GCP Secret Manager `pathology-hub-api-key`; stale Colab `X-API-Key`/`PATHOLOGY_HUB_API_KEY` values caused 401 during debugging.
6. Preserve the caution that v11 curriculum hardening is generated/planned but not live until run/promoted/API-proven.

Do not claim:
- explicit tag-browse fields are live under current v1.5.8 API,
- figure junk removal is exhaustive,
- raw PDFs/videos were altered,
- v11 is live.

