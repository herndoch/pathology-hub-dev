# Schema Registry Patch — Governed Tag Cleanup v10.5

## Governed metadata fields

Governed records may include:

- `primary_tag`: runtime/existing tag field after governance promotion.
- `primary_tag_governed`: governed tag value.
- `primary_tag_original_pre_governance_v10_4`: pre-governance tag value preserved for audit.
- `tag_governance_status`: e.g. `approved_exact`, `approved_local_pathout`, `inherited_context`, `rejected_generated`, `excluded_junk`, `unmapped_no_context`.
- `tag_governance_basis`: explanation/source of governed decision.
- `tag_authority`: e.g. `abpath_gold`, `who_processed_or_who_to_abpath`, `pathout_approved_local`.

## Governed tag index

v10.4 governed tag index summary:

- records: 323,274
- unique tags: 6,035
- unmapped records: 0
- forbidden generated lecture/textbook artifact tag patterns: 0

## API response schema note

Current proven API remains `evidence_search_response.v1.5.8`. Do not register tag-aware request fields as live until a backend deployment and OpenAPI schema prove them.
