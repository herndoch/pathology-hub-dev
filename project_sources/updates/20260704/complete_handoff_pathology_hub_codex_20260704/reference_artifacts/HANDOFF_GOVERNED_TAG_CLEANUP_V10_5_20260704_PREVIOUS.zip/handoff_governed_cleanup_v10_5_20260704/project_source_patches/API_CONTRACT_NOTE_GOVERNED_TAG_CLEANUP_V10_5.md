# API Contract Note — Governed Tag Cleanup v10.5

No new GPT Action is required.

Current proven endpoint:

```text
POST /evidence/search
operationId: searchEvidence
```

Authentication remains:

```text
Header name: X-API-Key
```

Debugging note:

- Colab secret `HUB_API` held the working key value.
- GCP Secret Manager `pathology-hub-api-key` matched the working value.
- Colab secrets named `X-API-Key` and `PATHOLOGY_HUB_API_KEY` were stale/wrong and returned 401 in debugging.
- GPT Builder should use the working value under header name `X-API-Key`.

Tag-aware request modes such as `tag_browse`, `tag_auto`, `tag_prefix`, or `tags` should not be added to the GPT Action schema until a tag-aware backend is deployed and proven.
