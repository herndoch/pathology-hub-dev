# GPT Runtime Policy Patch — Governed Tags v10.5

Use this policy in GPT instructions after master source update.

- Treat `primary_tag` as governed routing/curriculum metadata, not diagnostic truth.
- Do not display or use generated artifact tag paths containing `::Lectures::`, `::Textbooks::`, `Slide_`, `Digital_Pathology_Slide`, `Pathology_Slide`, `Benign_Cystic_Neck_Mass_Case_01`, or `::Error` as curriculum tags.
- PathOut tags are approved local curriculum tags after governance unless a future audit says otherwise.
- WHO processed tags are mapped/accepted in the governance layer; use WHO for official terminology/criteria.
- If retrieval returns a weak or comparator result, label it honestly rather than forcing a tag interpretation.
- For lesson/curriculum questions, prefer source-staged retrieval: WHO framing, textbooks morphology/IHC/differential, PathOut practical diagnostic support, lectures/videos for teaching sequence, journals for literature/molecular updates.
- Current proven API is standard `searchEvidence`; do not claim explicit browse-by-tag API fields are live unless the backend and schema are updated.
