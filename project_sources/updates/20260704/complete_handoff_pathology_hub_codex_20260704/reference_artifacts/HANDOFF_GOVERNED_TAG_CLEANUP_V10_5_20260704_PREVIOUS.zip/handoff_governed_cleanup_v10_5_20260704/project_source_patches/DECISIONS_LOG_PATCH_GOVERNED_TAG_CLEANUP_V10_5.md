# Decisions Log Patch — Governed Tag Cleanup v10.5 / Curriculum Mapping

## Decisions

1. ABPath source tags are gold curriculum tags.
2. WHO processed tags from `gs://pathology-hub-0/WHO/WHO_JSON_PROCESSED/*.json` are accepted into the governance layer after WHO-to-ABPath fuzzy mapping; threshold for future v11 hardening is score >= 90.
3. PathOut tags are auto-approved as local curriculum tags unless obvious artifact/root-error rules fail.
4. Lecture/textbook generated tags containing source artifacts (`::Lectures::`, `::Textbooks::`, `Slide_`, `Digital_Pathology_Slide`, `Pathology_Slide`, raw file/lecture/page artifacts) are not valid curriculum ontology nodes.
5. Weak-context lecture/textbook records should inherit prior meaningful tag within bounded sequence context; if no prior context exists, leave governed untagged/excluded from tag browsing.
6. Secondary curriculum facets are deferred.
7. Raw PDFs and videos are not modified by governance cleanup; only metadata/derived figure-map records are patched after backup.
8. Existing one-Action API architecture remains: `searchEvidence` / `POST /evidence/search`.
