# Current Master Spine Patch — Governed Tag Cleanup v10.5, 2026-07-04

## Add to source status / architecture notes

Governed tag cleanup v10.5 is live and authenticated API-proven for the existing `searchEvidence` endpoint. The cleanup governs retrieval-facing `primary_tag` metadata for textbooks, PathOut, and lectures/videos so generated lecture/textbook artifact tags are not exposed as curriculum tags.

Allowed status wording:

- ABPath tags are gold curriculum tags.
- WHO processed tags are mapped/accepted into the governance layer; WHO remains official terminology/criteria support.
- PathOut AP-diagnostic/local tags are approved local curriculum tags unless a future audit rejects specific branches.
- Lecture/textbook weak-context records should not create new ontology tags; they map to approved tags, inherit prior meaningful context, or remain governed untagged/excluded from tag browsing.
- Standard authenticated `searchEvidence` proof after v10.5 returned 200 for lecture, mixed WHO/textbook/PathOut/journal, and textbook/PathOut probes with 0 forbidden generated tag patterns returned.

## Do not overstate

Do not claim explicit tag-browse request fields are live unless a tag-aware backend and OpenAPI update are separately deployed and proven. Do not claim figure cleanup is exhaustive; v10.5 only applied the current served-map filter pass.
