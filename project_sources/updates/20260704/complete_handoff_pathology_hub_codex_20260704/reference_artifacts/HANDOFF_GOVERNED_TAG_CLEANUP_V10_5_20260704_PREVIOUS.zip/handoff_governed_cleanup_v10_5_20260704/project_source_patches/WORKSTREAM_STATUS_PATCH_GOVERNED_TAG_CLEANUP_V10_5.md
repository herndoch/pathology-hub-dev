# Workstream Status Patch — Governed Tag Cleanup v10.5

## Evidence/Lesson/Research RAG

### Governed curriculum tags

Status: live for standard retrieval metadata; authenticated API proof passed.

- Governed tag index generated in v10.4: 323,274 records; 6,035 unique tags; 0 `__UNMAPPED__`; 0 forbidden generated lecture/textbook artifact tag patterns.
- Backend-consumed metadata scan in v10.5:
  - textbooks: 79,320 vector-docstore records mapped in `primary_tag` and `primary_tag_governed`; 2,597 unique primary tags in scan.
  - PathOut: 4,397 records mapped in `primary_tag` and `primary_tag_governed`; 4,048 unique primary tags.
  - lectures/videos: 42,069 records mapped in `primary_tag` and `primary_tag_governed`; 1,647 unique primary tags.
- v10.5.2 authenticated API proof: 3/3 POST tests returned 200 and 0 forbidden returned primary tags.

### Remaining work

- Explicit tag browsing/tag-auto API mode remains pending unless separately deployed/proven.
- v11 curriculum hardening notebook exists but is not live until run/promoted/proven.
- Figure cleanup needs further audit if header/footer strip images remain visible.
