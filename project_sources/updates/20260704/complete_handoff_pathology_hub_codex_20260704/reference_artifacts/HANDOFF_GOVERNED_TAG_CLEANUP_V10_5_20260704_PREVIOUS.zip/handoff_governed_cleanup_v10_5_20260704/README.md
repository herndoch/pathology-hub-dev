# Handoff Package — Governed Tag Cleanup v10.5 / Curriculum Mapping Preparation

Created: 2026-07-04T16:38:27+00:00

This package is intended to be uploaded into the master Pathology Hub project conversation together with other handoff packets.

## What this handoff covers

This handoff summarizes the governed cleanup pass that removed generated lecture/textbook junk tags from live retrieval-facing metadata, accepted/normalized WHO processed tags, preserved PathOut as approved local curriculum tags, and produced authenticated API proof that standard `searchEvidence` calls no longer return forbidden lecture/textbook artifact tags.

## Most important status

**Governed tag cleanup v10.5 is promoted and authenticated API-proven for existing `searchEvidence` retrieval.**

Authenticated API proof using Colab secret `HUB_API` sent under HTTP header `X-API-Key` produced:

- `/health`: 200
- `sources=["lectures"]`: 200, forbidden returned primary tags = 0
- `sources=["who","textbooks","pathout","journals"]`: 200, forbidden returned primary tags = 0
- `sources=["textbooks","pathout"]`: 200, forbidden returned primary tags = 0

The proof was uploaded by the notebook to:

```text
gs://pathology_hub/06_audits/tags/governance/v10_5/PATHOLOGY_HUB_GOVERNED_CLEANUP_API_PROOF_v10_5_2.json
```

## Important distinction

This cleanup proves that the **current API** returns governed metadata without the forbidden tag patterns tested. It does **not** by itself prove that explicit tag browsing request fields such as `search_mode=tag_browse`, `tag_auto`, or `tag_prefix` are live. Those require a separate tag-aware backend deployment and OpenAPI update.

## Included files

- `HANDOFF_GOVERNED_TAG_CLEANUP_V10_5_20260704.md` — detailed handoff.
- `MASTER_CONVERSATION_UPDATE_PROMPT.md` — pasteable prompt for the master project conversation.
- `project_source_patches/*` — patch files for master spine, workstream status, schema registry, decisions log, and API contract note.
- `summaries/VALIDATION_SUMMARY_GOVERNED_TAG_CLEANUP_V10_5_HANDOFF.json` — machine-readable validation summary.
- `support/SOURCE_STATUS_MATRIX_GOVERNED_TAG_CLEANUP_V10_5.csv` — concise source status matrix.
- `support/GCS_PATHS_GOVERNED_TAG_CLEANUP_V10_5.csv` — important GCS paths.
- `support/API_KEY_AND_AUTH_NOTE.md` — API key clarification.
- `support/CURRICULUM_MAPPING_NEXT_STEPS_V11_NOT_LIVE.md` — v11 next-stage plan and status.
- `evidence/*` — original v10.4/v10.5 evidence summaries and synthesized v10.5.2 proof JSON.

