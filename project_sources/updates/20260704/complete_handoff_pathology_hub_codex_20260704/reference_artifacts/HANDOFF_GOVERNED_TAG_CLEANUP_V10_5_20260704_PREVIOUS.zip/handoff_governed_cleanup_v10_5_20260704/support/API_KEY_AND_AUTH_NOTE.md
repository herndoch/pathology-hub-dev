# API Key and Auth Note

During v10.5 proof, the notebook initially loaded a stale/wrong key from Colab secret names `X-API-Key` and `PATHOLOGY_HUB_API_KEY`. Those returned 401.

Diagnostic results showed:

```text
X-API-Key secret: loaded, length 43, 401 Unauthorized
PATHOLOGY_HUB_API_KEY secret: loaded, length 43, 401 Unauthorized
HUB_API secret: loaded, length 47, 200 OK
GCP Secret Manager pathology-hub-api-key: loaded, length 47, 200 OK
```

Correct usage:

```text
Colab secret name that worked: HUB_API
HTTP header name sent to backend: X-API-Key
```

GPT Builder should use the working key value from `HUB_API` / GCP Secret Manager, but the configured auth header name must remain `X-API-Key`.
