# Curriculum Mapping Next Steps — v11 Not Yet Live

A v11 curriculum tag hardening package was generated but is not part of the live/proven status in this handoff unless separately run and uploaded.

User decisions for v11:

1. PathOut-only tags: auto-approve as local curriculum tags.
2. WHO fuzzy matches to ABPath: auto-accept at score >= 90.
3. Weak lecture/textbook chunks: use max-distance inheritance.
   - Lecture default proposed: 10 minutes / 12 rows.
   - Textbook default proposed: 2 pages / 25 rows.
4. If no prior meaningful tag exists, keep vector-searchable but exclude from tag browsing/curriculum maps.
5. Hold off on secondary content-role facets for now.
6. Keep PathOut-only local tags and approve all unless future audit rejects them.

v11 should not be marked live until:

- notebook run completes,
- clear audit passes,
- promotion occurs,
- Cloud Run restarts,
- authenticated API proof returns 200 with 0 forbidden/generated artifact tags,
- output ZIP is reviewed.
