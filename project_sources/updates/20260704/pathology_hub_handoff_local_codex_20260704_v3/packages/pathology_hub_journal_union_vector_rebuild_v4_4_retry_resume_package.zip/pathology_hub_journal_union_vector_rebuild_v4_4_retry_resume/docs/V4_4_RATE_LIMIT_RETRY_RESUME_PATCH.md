# v4.4 rate-limit retry/resume patch

The uploaded v4.3 run proved the package path and secrets were correct, then failed during OpenAI embeddings with a 429 TPM rate limit. v4.4 changes the actual script, not just the wrapper notebook.

Changes:
- Script renamed to `journal_union_vector_rebuild_v4_4_retry_resume.py`.
- Default `EMBED_BATCH_SIZE` lowered from 128 to 64.
- Adds `EMBED_TPM_BUDGET` throttle, default 700,000 approximate tokens/minute.
- Adds retry/backoff for 429/rate-limit exceptions.
- Writes `new_embeddings_checkpoint_v4_4.npy` and metadata after every batch.
- Notebook sets stable `WORKDIR=/content/journal_union_vector_rebuild_v4_4_retry_resume_work`, so rerunning Cell 4 resumes from checkpoint in the same runtime.

Do not use v4/v4.1/v4.2/v4.3 for the vector rebuild.
