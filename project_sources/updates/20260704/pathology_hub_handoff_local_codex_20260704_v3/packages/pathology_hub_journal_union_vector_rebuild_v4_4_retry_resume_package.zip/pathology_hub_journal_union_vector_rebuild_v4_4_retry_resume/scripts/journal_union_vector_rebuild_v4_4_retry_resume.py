#!/usr/bin/env python3
# v4.4 retry/resume patch: rate-limit aware embeddings with checkpoint resume.
# v4.1 auth handoff patch: API proof tries HUB_API first but still sends HTTP header X-API-Key.
from __future__ import annotations
import os, re, json, csv, html, time, zipfile, hashlib, subprocess, datetime, sys, importlib.util
from pathlib import Path
from collections import Counter, defaultdict
from datetime import timezone

PROJECT_ID = os.environ.get('PROJECT_ID','pathology-annotation-project')
REGION = os.environ.get('REGION','us-central1')
SERVICE_NAME = os.environ.get('SERVICE_NAME','pathology-hub-v04')
API_BASE_URL = os.environ.get('API_BASE_URL','https://pathology-hub-v04-vorn5q2kga-uc.a.run.app')
RUN_TS = datetime.datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
WORKDIR = Path(os.environ.get('WORKDIR', f'/content/journal_union_vector_rebuild_v4_4_{RUN_TS}'))
INPUT = WORKDIR/'input'; OUT=WORKDIR/'output'; AUDIT=WORKDIR/'audit'; STAGE=WORKDIR/'stage'
for p in [INPUT,OUT,AUDIT,STAGE]: p.mkdir(parents=True, exist_ok=True)

PROMOTE_BROWSER = os.environ.get('PROMOTE_BROWSER','true').lower()=='true'
BUILD_AND_PROMOTE_VECTOR = os.environ.get('BUILD_AND_PROMOTE_VECTOR','true').lower()=='true'
RESTART_CLOUD_RUN = os.environ.get('RESTART_CLOUD_RUN','true').lower()=='true'
RUN_API_PROOF = os.environ.get('RUN_API_PROOF','true').lower()=='true'
OPENAI_API_KEY_SECRET_NAME = os.environ.get('OPENAI_API_KEY_SECRET_NAME','OPEN_AI_KEY_01')
API_KEY_SECRET_NAMES = [x.strip() for x in os.environ.get('API_KEY_SECRET_NAMES','HUB_API,X-API-Key,X_API_KEY,PATHOLOGY_HUB_API_KEY').split(',') if x.strip()]
EMBEDDING_MODEL = os.environ.get('EMBEDDING_MODEL','text-embedding-3-small')
EMBED_BATCH_SIZE = int(os.environ.get('EMBED_BATCH_SIZE','64'))
EMBED_TPM_BUDGET = int(os.environ.get('EMBED_TPM_BUDGET','700000'))
EMBED_MAX_RETRIES = int(os.environ.get('EMBED_MAX_RETRIES','12'))
EMBED_RETRY_BASE_SLEEP = float(os.environ.get('EMBED_RETRY_BASE_SLEEP','8'))
EMBED_CHECKPOINT_EVERY_BATCH = os.environ.get('EMBED_CHECKPOINT_EVERY_BATCH','true').lower()=='true'
MAX_NEW_ROWS_TO_EMBED = int(os.environ.get('MAX_NEW_ROWS_TO_EMBED','0')) # 0 means no limit
MIN_NEW_ARTICLES_REQUIRED_FOR_VECTOR_PROMOTION = int(os.environ.get('MIN_NEW_ARTICLES_REQUIRED_FOR_VECTOR_PROMOTION','1'))

GCS = {
 'current_docstore': 'gs://pathology_hub/03_indexes/journals/vector/journal_vector_docstore.jsonl',
 'current_embeddings': 'gs://pathology_hub/03_indexes/journals/vector/journal_embeddings.npy',
 'current_faiss': 'gs://pathology_hub/03_indexes/journals/vector/journal_faiss.index',
 'current_manifest': 'gs://pathology_hub/03_indexes/journals/vector/journal_vector_manifest.json',
 'normalized_recursive': 'gs://pathology_hub/02_normalized/journals/**',
 'live_browser': 'gs://pathology_hub/05_html/article_browser/article_browser.html',
 'live_chunk_browser': 'gs://pathology_hub/05_html/article_browser/journal_chunk_browser.html',
}
GCS_STAGE_ROOT = f'gs://pathology_hub/03_indexes/journals/vector_union_v4_4/{RUN_TS}'
GCS_AUDIT_ROOT = f'gs://pathology_hub/06_audits/journals/vector_union_v4_4/{RUN_TS}'
GCS_BACKUP_ROOT = f'gs://pathology_hub/99_backups/journal_union_vector_v4_4/{RUN_TS}'

def now(): return datetime.datetime.now(timezone.utc).replace(microsecond=0).isoformat()
def sh(cmd, check=True, timeout=900):
    print(f"\n[{now()}] START: {cmd}", flush=True)
    t=time.time(); p=subprocess.run(cmd,shell=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout)
    if p.stdout: print(p.stdout[-12000:], flush=True)
    print(f"[{now()}] DONE rc={p.returncode} elapsed={time.time()-t:.1f}s", flush=True)
    if check and p.returncode!=0: raise RuntimeError(cmd)
    return p

def gcs_cp(src,dst,check=True,timeout=1800):
    if not str(dst).startswith('gs://'): Path(dst).parent.mkdir(parents=True, exist_ok=True)
    return sh(f"gcloud storage cp '{src}' '{dst}'", check=check, timeout=timeout)
def gcs_ls(pattern, check=False):
    p=sh(f"gcloud storage ls '{pattern}'", check=check, timeout=600)
    return [x.strip() for x in p.stdout.splitlines() if x.strip().startswith('gs://')]
def read_jsonl(path):
    with open(path, encoding='utf-8', errors='replace') as f:
        for line in f:
            line=line.strip()
            if line:
                try: yield json.loads(line)
                except Exception: continue
def write_jsonl(rows,path):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with open(path,'w',encoding='utf-8') as f:
        for r in rows: f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
def read_json(path, default=None):
    try: return json.loads(Path(path).read_text(encoding='utf-8'))
    except Exception: return default
def write_json(obj,path):
    Path(path).parent.mkdir(parents=True, exist_ok=True); Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
def sha(path):
    h=hashlib.sha256();
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def get(row, keys, default=''):
    if not isinstance(row,dict): return default
    for k in keys:
        v=row.get(k)
        if v not in [None,'']: return v
    md=row.get('metadata') if isinstance(row.get('metadata'),dict) else {}
    for k in keys:
        v=md.get(k)
        if v not in [None,'']: return v
    return default

def norm_text(s):
    s=str(s or '').lower()
    s=re.sub(r'[^a-z0-9]+',' ',s)
    return re.sub(r'\s+',' ',s).strip()
def journal_of(r): return str(get(r,['journal','journal_name','source_journal','publication','source_title'],'Unknown Journal') or 'Unknown Journal').strip()
def title_of(r): return str(get(r,['title','article_title','source_title','name'],'Untitled') or 'Untitled').strip()
def doi_of(r): return str(get(r,['doi','DOI'],'') or '').strip().lower()
def url_of(r): return str(get(r,['url','source_url','article_url','doi_url','pdf_url'],'') or '').strip()
def published_of(r): return str(get(r,['published','publication_date','date','year'],'') or '').strip()
def excerpt_of(r):
    v=get(r,['excerpt','text','chunk_text','abstract','body','content'], '')
    if isinstance(v,(dict,list)): v=json.dumps(v,ensure_ascii=False)
    return str(v or '')
def article_key(r):
    doi=doi_of(r)
    if doi: return 'doi:'+doi
    return 'jt:'+norm_text(journal_of(r))+'|'+norm_text(title_of(r))
def row_fingerprint(r):
    base='|'.join([article_key(r), str(get(r,['chunk_id','id','record_id','page','section'],'')), norm_text(excerpt_of(r))[:500]])
    return hashlib.sha1(base.encode('utf-8')).hexdigest()
def canonicalize_row(r, source_uri):
    rr=dict(r)
    rr.setdefault('journal', journal_of(r)); rr.setdefault('title', title_of(r)); rr.setdefault('doi', doi_of(r)); rr.setdefault('url', url_of(r)); rr.setdefault('published', published_of(r))
    txt=excerpt_of(r); rr['excerpt']=txt
    rr['journal_union_v4_source_uri']=source_uri
    rr['journal_union_v4_article_key']=article_key(rr)
    rr['journal_union_v4_row_fingerprint']=row_fingerprint(rr)
    return rr

def summarize_rows(rows, name, source_uri=''):
    articles={article_key(r) for r in rows}
    jc=Counter(journal_of(r) for r in rows)
    return {'source_name':name,'gcs_uri':source_uri,'row_count':len(rows),'article_count':len(articles),'journal_counts':dict(jc),'field_coverage':{k:sum(1 for r in rows if get(r,[k],'')) for k in ['journal','title','doi','url','published','year']}, 'excerpt_rows': sum(1 for r in rows if excerpt_of(r))}

def build_articles(rows):
    by={}
    for r in rows:
        k=article_key(r)
        a=by.setdefault(k, {'article_key':k,'journal':journal_of(r),'title':title_of(r),'doi':doi_of(r),'url':url_of(r),'published':published_of(r),'chunk_count':0,'source_uris':set(),'excerpt':''})
        a['chunk_count']+=1
        a['source_uris'].add(str(r.get('journal_union_v4_source_uri','')))
        if not a['excerpt'] and excerpt_of(r): a['excerpt']=excerpt_of(r)[:1000]
        for fld,func in [('doi',doi_of),('url',url_of),('published',published_of)]:
            if not a[fld] and func(r): a[fld]=func(r)
    out=[]
    for a in by.values():
        a['source_uris']='|'.join(sorted(x for x in a['source_uris'] if x)); out.append(a)
    return sorted(out, key=lambda x:(x['journal'].lower(), x['title'].lower()))

def write_browser(articles, chunks):
    article_csv=OUT/'journal_article_browser_v4_articles.csv'
    with open(article_csv,'w',newline='',encoding='utf-8') as f:
        fields=['journal','title','doi','url','published','chunk_count','article_key','source_uris','excerpt']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([{k:a.get(k,'') for k in fields} for a in articles])
    write_jsonl(articles, OUT/'journal_article_browser_v4_articles.jsonl')
    with open(OUT/'journal_chunk_browser_v4_chunks.csv','w',newline='',encoding='utf-8') as f:
        fields=['journal','title','doi','url','published','chunk_id','article_key','source_uri','excerpt']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for r in chunks:
            w.writerow({'journal':journal_of(r),'title':title_of(r),'doi':doi_of(r),'url':url_of(r),'published':published_of(r),'chunk_id':get(r,['chunk_id','id','record_id'],''),'article_key':article_key(r),'source_uri':r.get('journal_union_v4_source_uri',''),'excerpt':excerpt_of(r)[:2000]})
    counts=Counter(a['journal'] for a in articles)
    rows='\n'.join(f"<tr><td>{html.escape(a['journal'])}</td><td>{html.escape(a['title'])}</td><td>{html.escape(a['doi'])}</td><td>{html.escape(a['published'])}</td><td>{a['chunk_count']}</td><td>{'<a href='+html.escape(a['url'])+'>link</a>' if a['url'] else ''}</td></tr>" for a in articles)
    summary='; '.join(f'{html.escape(k)}: {v}' for k,v in counts.items())
    doc=f"""<!doctype html><html><head><meta charset='utf-8'><title>Pathology Hub Journal Browser v4</title><style>body{{font-family:Arial;margin:20px}}input{{width:100%;padding:8px;font-size:16px}}table{{border-collapse:collapse;width:100%;margin-top:10px}}td,th{{border:1px solid #ddd;padding:4px}}tr:nth-child(even){{background:#f8f8f8}}</style><script>function filt(){{let q=document.getElementById('q').value.toLowerCase();document.querySelectorAll('tbody tr').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q)?'':'none')}}</script></head><body><h1>Pathology Hub Journal Browser v4</h1><p>Generated {now()}. Articles: {len(articles)}. Chunks: {len(chunks)}.</p><p>{summary}</p><input id='q' oninput='filt()' placeholder='Search title, journal, DOI...'><table><thead><tr><th>Journal</th><th>Title</th><th>DOI</th><th>Published</th><th>Chunks</th><th>URL</th></tr></thead><tbody>{rows}</tbody></table></body></html>"""
    (OUT/'journal_article_browser_v4.html').write_text(doc,encoding='utf-8')
    # chunk browser can be huge but useful as artifact
    crow='\n'.join(f"<tr><td>{html.escape(journal_of(r))}</td><td>{html.escape(title_of(r))}</td><td>{html.escape(str(get(r,['chunk_id','id','record_id'],'')))}</td><td>{html.escape(excerpt_of(r)[:500])}</td></tr>" for r in chunks)
    (OUT/'journal_chunk_browser_v4.html').write_text(f"<!doctype html><html><head><meta charset='utf-8'><title>Journal Chunk Browser v4</title><style>body{{font-family:Arial;margin:20px}}td,th{{border:1px solid #ddd;padding:4px}}table{{border-collapse:collapse;width:100%}}</style></head><body><h1>Journal Chunk Browser v4</h1><p>{len(chunks)} chunks</p><table><thead><tr><th>Journal</th><th>Title</th><th>Chunk</th><th>Excerpt</th></tr></thead><tbody>{crow}</tbody></table></body></html>",encoding='utf-8')


def _estimate_tokens_for_batch(batch):
    # Conservative enough for TPM throttling; embeddings endpoint tokenization is not exact here.
    return sum(max(1, len(str(x))//4) for x in batch)


def _texts_fingerprint(texts):
    h=hashlib.sha256()
    h.update(str(len(texts)).encode())
    for t in texts:
        h.update(b'\0')
        h.update(str(t).encode('utf-8', errors='replace')[:2000])
    return h.hexdigest()


def embed_texts(texts):
    # v4.4: rate-limit aware, checkpointed, and resumable.
    api_key=os.environ.get('OPENAI_API_KEY') or os.environ.get(OPENAI_API_KEY_SECRET_NAME)
    if not api_key:
        try:
            from google.colab import userdata
            api_key=userdata.get(OPENAI_API_KEY_SECRET_NAME)
        except Exception:
            api_key=None
    if not api_key:
        raise RuntimeError(f'OpenAI API key unavailable. Export OPENAI_API_KEY/OPEN_AI_KEY_01 before subprocess launch.')
    ensure_pkg('openai')
    from openai import OpenAI
    import numpy as np
    client=OpenAI(api_key=api_key)

    checkpoint_vec = OUT/'new_embeddings_checkpoint_v4_4.npy'
    checkpoint_meta = OUT/'new_embeddings_checkpoint_v4_4_meta.json'
    texts_fp=_texts_fingerprint(texts)
    out=[]
    start_i=0
    if checkpoint_vec.exists() and checkpoint_meta.exists():
        meta=read_json(checkpoint_meta,{}) or {}
        if meta.get('texts_fingerprint')==texts_fp and int(meta.get('texts_count',-1))==len(texts):
            arr=np.load(checkpoint_vec)
            if arr.ndim==2 and arr.shape[0] > 0 and arr.shape[0] <= len(texts):
                out=arr.astype('float32').tolist()
                start_i=arr.shape[0]
                print(f'Resuming embeddings from checkpoint rows={start_i}/{len(texts)}')
        else:
            print('Ignoring stale embedding checkpoint: fingerprint/count mismatch')

    # Rolling TPM throttle.
    token_window=[]  # list of (timestamp, approx_tokens)
    def throttle(batch_tokens):
        now_ts=time.time()
        while token_window and now_ts-token_window[0][0] > 60:
            token_window.pop(0)
        used=sum(t for _,t in token_window)
        if used + batch_tokens > EMBED_TPM_BUDGET and token_window:
            wait=max(1.0, 61 - (now_ts-token_window[0][0]))
            print(f'TPM throttle: used~{used}, batch~{batch_tokens}, budget={EMBED_TPM_BUDGET}; sleeping {wait:.1f}s')
            time.sleep(wait)
            throttle(batch_tokens)
        else:
            token_window.append((time.time(), batch_tokens))

    i=start_i
    while i < len(texts):
        batch=texts[i:i+EMBED_BATCH_SIZE]
        batch_tokens=_estimate_tokens_for_batch(batch)
        throttle(batch_tokens)
        print(f'Embedding {i}-{i+len(batch)} / {len(texts)} approx_tokens={batch_tokens}')
        for attempt in range(EMBED_MAX_RETRIES+1):
            try:
                resp=client.embeddings.create(model=EMBEDDING_MODEL, input=batch)
                arr=[d.embedding for d in resp.data]
                out.extend(arr)
                i += len(batch)
                if EMBED_CHECKPOINT_EVERY_BATCH:
                    tmp=np.asarray(out,dtype='float32')
                    np.save(checkpoint_vec,tmp)
                    write_json({'texts_count':len(texts),'texts_fingerprint':texts_fp,'embedded_rows':len(out),'updated_at_utc':now(),'embedding_model':EMBEDDING_MODEL,'batch_size':EMBED_BATCH_SIZE,'tpm_budget':EMBED_TPM_BUDGET}, checkpoint_meta)
                break
            except Exception as e:
                msg=str(e)
                is_rate = ('rate limit' in msg.lower()) or ('429' in msg) or (e.__class__.__name__.lower().find('ratelimit')>=0)
                if not is_rate or attempt >= EMBED_MAX_RETRIES:
                    print('Embedding request failed permanently at rows', i, i+len(batch), 'attempt', attempt, 'error_class', e.__class__.__name__)
                    raise
                # The OpenAI error may say try again in ms, but use a safer backoff to let TPM drain.
                sleep_s=min(180.0, EMBED_RETRY_BASE_SLEEP*(2**min(attempt,5)))
                print(f'Rate limit at rows {i}-{i+len(batch)} attempt {attempt+1}/{EMBED_MAX_RETRIES}; sleeping {sleep_s:.1f}s')
                time.sleep(sleep_s)
    vec=np.asarray(out,dtype='float32')
    norms=np.linalg.norm(vec,axis=1,keepdims=True)
    norms[norms==0]=1
    return vec/norms


def ensure_pkg(pkg, import_name=None):
    import_name=import_name or pkg
    if importlib.util.find_spec(import_name) is None:
        subprocess.run([sys.executable,'-m','pip','install','-q',pkg],check=True)

def main():
    print('WORKDIR', WORKDIR)
    sh(f'gcloud config set project {PROJECT_ID}', check=False, timeout=120)
    # Download current vector docstore/embeddings/manifest
    cur_doc=INPUT/'journal_vector_docstore_current.jsonl'; gcs_cp(GCS['current_docstore'], cur_doc, timeout=1800)
    cur_manifest=INPUT/'journal_vector_manifest_current.json'; gcs_cp(GCS['current_manifest'], cur_manifest, timeout=600)
    current=[canonicalize_row(r, GCS['current_docstore']) for r in read_jsonl(cur_doc)]
    current_article_keys={article_key(r) for r in current}; current_row_fps={row_fingerprint(r) for r in current}
    current_summary=summarize_rows(current,'current_vector_docstore',GCS['current_docstore'])
    # Inventory candidates
    uris=gcs_ls(GCS['normalized_recursive'])
    chunk_uris=sorted(set(u for u in uris if u.endswith('journal_chunks.jsonl') or u.endswith('_journal_chunks.jsonl')))
    print('Candidate journal chunk sources:', len(chunk_uris))
    candidate_summaries=[]; new_rows=[]; by_uri_new=Counter(); by_uri_seen=Counter()
    for idx,uri in enumerate(chunk_uris):
        local=INPUT/(f'candidate_{idx:03d}_'+Path(uri).name)
        gcs_cp(uri, local, check=False, timeout=1800)
        if not local.exists() or local.stat().st_size==0: continue
        rows=[canonicalize_row(r,uri) for r in read_jsonl(local)]
        candidate_summaries.append(summarize_rows(rows,f'candidate_{idx}',uri))
        for r in rows:
            by_uri_seen[uri]+=1
            fp=row_fingerprint(r)
            # Add if article not currently present OR exact row not present. This preserves extra chunks from same article if needed.
            if article_key(r) not in current_article_keys and fp not in current_row_fps:
                new_rows.append(r); current_row_fps.add(fp); by_uri_new[uri]+=1
    union_rows=current+new_rows
    union_articles=build_articles(union_rows)
    union_summary=summarize_rows(union_rows,'union_current_plus_missing_normalized_chunks','union')
    audit={'schema_version':'journal_union_coverage_audit.v4','generated_at_utc':now(),'current_summary':current_summary,'candidate_count':len(candidate_summaries),'candidate_summaries':candidate_summaries,'new_rows_added':len(new_rows),'new_articles_added':len({article_key(r) for r in new_rows}),'new_rows_by_source_uri':dict(by_uri_new),'union_summary':union_summary,'stage_root':GCS_STAGE_ROOT,'audit_root':GCS_AUDIT_ROOT}
    write_json(audit, AUDIT/'journal_union_coverage_audit_v4.json')
    print(json.dumps({k:audit[k] for k in ['current_summary','new_rows_added','new_articles_added','new_rows_by_source_uri','union_summary']},indent=2)[:10000])
    if len(new_rows)==0:
        raise RuntimeError('No missing rows found; nothing to rebuild.')
    # Write union docstore and browser
    union_doc=OUT/'journal_vector_docstore_union_v4.jsonl'; write_jsonl(union_rows, union_doc)
    articles=build_articles(union_rows); write_browser(articles, union_rows)
    # Stage browser
    for f in ['journal_article_browser_v4.html','journal_chunk_browser_v4.html','journal_article_browser_v4_articles.csv','journal_article_browser_v4_articles.jsonl','journal_chunk_browser_v4_chunks.csv']:
        gcs_cp(OUT/f, f'{GCS_STAGE_ROOT}/{f}', timeout=1800)
    gcs_cp(AUDIT/'journal_union_coverage_audit_v4.json', f'{GCS_AUDIT_ROOT}/journal_union_coverage_audit_v4.json')
    browser_promotion={'schema_version':'journal_browser_union_promotion.v4','generated_at_utc':now(),'promote_browser':PROMOTE_BROWSER,'performed':False,'objects':[]}
    if PROMOTE_BROWSER:
        bkp=f'{GCS_BACKUP_ROOT}/article_browser.html'; gcs_cp(GCS['live_browser'], bkp, check=False, timeout=600)
        gcs_cp(OUT/'journal_article_browser_v4.html', GCS['live_browser'], timeout=1800)
        # chunk browser gets sidecar path, not old main page
        gcs_cp(OUT/'journal_chunk_browser_v4.html', GCS['live_chunk_browser'], timeout=1800)
        browser_promotion['performed']=True; browser_promotion['objects']=[{'live':GCS['live_browser'],'backup':bkp},{'live':GCS['live_chunk_browser'],'backup':None}]
    write_json(browser_promotion,AUDIT/'journal_browser_union_promotion_audit_v4.json'); gcs_cp(AUDIT/'journal_browser_union_promotion_audit_v4.json', f'{GCS_AUDIT_ROOT}/journal_browser_union_promotion_audit_v4.json')
    vector_audit={'schema_version':'journal_vector_append_rebuild_audit.v4','generated_at_utc':now(),'build_and_promote_vector':BUILD_AND_PROMOTE_VECTOR,'performed':False,'new_rows_to_embed':len(new_rows)}
    if BUILD_AND_PROMOTE_VECTOR:
        if len({article_key(r) for r in new_rows}) < MIN_NEW_ARTICLES_REQUIRED_FOR_VECTOR_PROMOTION:
            raise RuntimeError('New article count below promotion threshold')
        ensure_pkg('numpy'); ensure_pkg('faiss-cpu','faiss')
        import numpy as np, faiss
        cur_emb=INPUT/'journal_embeddings_current.npy'; gcs_cp(GCS['current_embeddings'], cur_emb, timeout=2400)
        current_emb=np.load(cur_emb)
        embed_rows=new_rows[:MAX_NEW_ROWS_TO_EMBED] if MAX_NEW_ROWS_TO_EMBED else new_rows
        if len(embed_rows)!=len(new_rows):
            print('WARNING: embedding limited by MAX_NEW_ROWS_TO_EMBED; vector promotion should not be used for partial rebuild')
            raise RuntimeError('Partial embedding limit is set; refusing vector promotion')
        texts=[]
        for r in embed_rows:
            text='\n'.join([title_of(r), journal_of(r), doi_of(r), excerpt_of(r)[:3500]]).strip()
            texts.append(text or title_of(r) or journal_of(r))
        new_emb=embed_texts(texts)
        if current_emb.shape[1]!=new_emb.shape[1]:
            raise RuntimeError(f'Embedding dim mismatch current {current_emb.shape} new {new_emb.shape}')
        combined=np.vstack([current_emb.astype('float32'), new_emb.astype('float32')])
        np.save(OUT/'journal_embeddings_union_v4.npy', combined)
        index=faiss.IndexFlatIP(combined.shape[1]); index.add(combined)
        faiss.write_index(index, str(OUT/'journal_faiss_union_v4.index'))
        manifest=read_json(cur_manifest,{}) or {}
        manifest.update({'schema_version':'journal_vector_manifest.v4_union','created_at_utc':now(),'corpus':'journals_union','workstream':'Journal RAG / Vectorization / Union append','index_type':'faiss_IndexFlatIP_cosine_normalized','searchable':True,'vectorized':True,'api_exposed':True,'embedding_model':EMBEDDING_MODEL,'embedding_dim':int(combined.shape[1]),'record_count':len(union_rows),'previous_record_count':len(current),'new_record_count_added':len(new_rows),'article_count':len(articles),'journal_counts':union_summary['journal_counts'],'artifact_paths':{'embeddings_npy':'gs://pathology_hub/03_indexes/journals/vector/journal_embeddings.npy','faiss_index':'gs://pathology_hub/03_indexes/journals/vector/journal_faiss.index','docstore_jsonl':'gs://pathology_hub/03_indexes/journals/vector/journal_vector_docstore.jsonl','manifest_json':'gs://pathology_hub/03_indexes/journals/vector/journal_vector_manifest.json'},'checks':{'embedding_rows':int(combined.shape[0]),'docstore_rows':len(union_rows),'faiss_ntotal':int(index.ntotal),'zero_norm_rows':0}})
        write_json(manifest, OUT/'journal_vector_manifest_union_v4.json')
        # Upload staged vector artifacts
        gcs_cp(OUT/'journal_embeddings_union_v4.npy', f'{GCS_STAGE_ROOT}/journal_embeddings_union_v4.npy', timeout=3600)
        gcs_cp(OUT/'journal_faiss_union_v4.index', f'{GCS_STAGE_ROOT}/journal_faiss_union_v4.index', timeout=2400)
        gcs_cp(union_doc, f'{GCS_STAGE_ROOT}/journal_vector_docstore_union_v4.jsonl', timeout=2400)
        gcs_cp(OUT/'journal_vector_manifest_union_v4.json', f'{GCS_STAGE_ROOT}/journal_vector_manifest_union_v4.json')
        # Backup and replace live vector artifacts
        for live, local in [(GCS['current_embeddings'], OUT/'journal_embeddings_union_v4.npy'),(GCS['current_faiss'], OUT/'journal_faiss_union_v4.index'),(GCS['current_docstore'], union_doc),(GCS['current_manifest'], OUT/'journal_vector_manifest_union_v4.json')]:
            backup=f'{GCS_BACKUP_ROOT}/{Path(live).name}'
            gcs_cp(live, backup, check=False, timeout=2400); gcs_cp(local, live, timeout=3600)
        vector_audit.update({'performed':True,'previous_rows':len(current),'new_rows_added':len(new_rows),'new_articles_added':len({article_key(r) for r in new_rows}),'union_rows':len(union_rows),'union_articles':len(articles),'journal_counts':union_summary['journal_counts']})
        if RESTART_CLOUD_RUN:
            p=sh(f"gcloud run services update {SERVICE_NAME} --region={REGION} --update-env-vars=JOURNAL_UNION_VECTOR_V4_3_TS={RUN_TS} --quiet", check=False, timeout=900)
            vector_audit['cloud_run_restart_returncode']=p.returncode
    write_json(vector_audit,AUDIT/'journal_vector_append_rebuild_audit_v4.json'); gcs_cp(AUDIT/'journal_vector_append_rebuild_audit_v4.json', f'{GCS_AUDIT_ROOT}/journal_vector_append_rebuild_audit_v4.json')
    proof={'schema_version':'journal_union_v4_api_proof','generated_at_utc':now(),'health':None,'api_probes':[]}
    if RUN_API_PROOF:
        try:
            r=requests.get(API_BASE_URL+'/health', timeout=30); proof['health']={'status_code':r.status_code,'text':r.text[:5000]}
        except Exception as e: proof['health']={'error':str(e)}
        api_key=None
        tried=[]
        # v4.2: prefer env because notebook exports secrets before launching subprocess.
        for env_name in ['PATHOLOGY_HUB_API_KEY','HUB_API','X_API_KEY'] + API_KEY_SECRET_NAMES:
            tried.append('env:'+env_name)
            api_key=os.environ.get(env_name)
            if api_key:
                proof['api_key_secret_used']='env:'+env_name
                break
        if not api_key:
            try:
                from google.colab import userdata
                for secret_name in API_KEY_SECRET_NAMES:
                    tried.append(secret_name)
                    try:
                        api_key=userdata.get(secret_name)
                    except Exception:
                        api_key=None
                    if api_key:
                        proof['api_key_secret_used']=secret_name
                        break
            except Exception:
                pass
        proof['api_key_secret_names_tried']=tried
        if api_key:
            headers={'X-API-Key':api_key,'Content-Type':'application/json'}
            for q in ['Virchows Archiv colorectal carcinoma', 'Virchows Archiv lymphoma pathology', 'Modern Pathology lung adenocarcinoma AJSP']:
                payload={'query':q,'sources':['journals'],'max_results':5,'compact':True,'excerpt_char_limit':900}
                try:
                    rr=requests.post(API_BASE_URL+'/evidence/search',headers=headers,json=payload,timeout=60)
                    proof['api_probes'].append({'payload':payload,'status_code':rr.status_code,'text':rr.text[:3000],'contains_virchows':('Virchows' in rr.text)})
                except Exception as e: proof['api_probes'].append({'payload':payload,'error':str(e)})
        else:
            proof['api_proof_note']='No API key secret available. Tried HUB_API, X-API-Key, X_API_KEY, PATHOLOGY_HUB_API_KEY; HTTP header remains X-API-Key.'
    write_json(proof,AUDIT/'journal_union_v4_api_proof.json'); gcs_cp(AUDIT/'journal_union_v4_api_proof.json', f'{GCS_AUDIT_ROOT}/journal_union_v4_api_proof.json', check=False)
    # final report/zip
    report={'schema_version':'journal_union_vector_rebuild_report.v4','generated_at_utc':now(),'coverage_audit':audit,'browser_promotion':browser_promotion,'vector_audit':vector_audit,'api_proof':proof,'gcs_stage_root':GCS_STAGE_ROOT,'gcs_audit_root':GCS_AUDIT_ROOT,'gcs_backup_root':GCS_BACKUP_ROOT}
    write_json(report, OUT/'JOURNAL_UNION_VECTOR_REBUILD_REPORT_v4.json')
    files=[]
    for folder in [OUT,AUDIT]:
        for p in folder.glob('*'):
            if p.is_file(): files.append({'name':p.name,'size_bytes':p.stat().st_size,'sha256':sha(p)})
    write_json({'schema_version':'journal_union_v4_checksum_manifest','files':files}, OUT/'SHA256_MANIFEST_JOURNAL_UNION_V4.json')
    zip_path=WORKDIR/f'JOURNAL_UNION_VECTOR_REBUILD_V4_4_OUTPUTS_{RUN_TS}.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in [OUT,AUDIT]:
            for p in folder.glob('*'):
                if p.is_file(): z.write(p, arcname=p.name)
    Path('/content/LATEST_JOURNAL_UNION_VECTOR_REBUILD_V4_4_OUTPUT_ZIP.txt').write_text(str(zip_path))
    print('OUTPUT ZIP', zip_path)

if __name__=='__main__': main()
